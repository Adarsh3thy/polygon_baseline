const express = require('express');
const app = express();
const Web3 = require('web3');
const abi = require('./contracts/NFTMarketplace.json'); // Insert the ABI of your smart contract here
const contractAddress = '0xA75E7699B1B10728872066a7E0d62bA829590c60'; // Insert the address of your smart contract here

// Set up a connection to a Web3 provider
const web3 = new Web3(new Web3.providers.HttpProvider('https://polygon-mumbai.infura.io/v3/92d451dad4924a55be3ebeab3cade25e'));

// Create an instance of the smart contract
const contractInstance = new web3.eth.Contract(abi.abi, contractAddress);

// Define a route that calls the fetchMarketItems function of the smart contract
app.get('/marketItems', async (req, res) => {
  try {
    const result = await contractInstance.methods.fetchMarketItems().call();
    res.send(result);
  } catch (error) {
    console.error(error);
    res.status(500).send('Something went wrong');
  }
});

// Start the server
app.listen(4000, () => {
  console.log('Server started on port 4000');
});
